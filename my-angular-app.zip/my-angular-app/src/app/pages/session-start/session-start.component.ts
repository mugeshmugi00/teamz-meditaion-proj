import { Component } from '@angular/core';

@Component({
  selector: 'app-session-start',
  imports: [],
  templateUrl: './session-start.component.html',
  styleUrl: './session-start.component.css'
})
export class SessionStartComponent {

}
